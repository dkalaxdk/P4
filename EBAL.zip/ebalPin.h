//
// Created by titan on 29-04-2020.
//

#ifndef EBAL_EBALPIN_H
#define EBAL_EBALPIN_H

#include "ebal.h"

enum PinType { digital, analog, pwm };
enum IOType { input, output };
enum FilterType { debounce, constant, range };

/**
 * Class that represents a pin from EBAL in the context of Arduino.
 */
class ebalPin {
    int pinNumber;
    PinType pinType;
    IOType ioType;

    int value;
    int previousValue;

    int lastFilterTime = 0;

    public:
        int getValue();
        void createPin(PinType pinT, IOType ioT, int n);
        int filterNoise(FilterType);
        void read();
        void write(int output);

    private:
        int Range();
        int Debounce();
        int Constant();
};

#endif //EBAL_EBALPIN_H