//
// Created by titan on 29-04-2020.
//

#include "ebalPin.h"

/**
 * Method that reads the value from a pin, depending on the type of the pin (digital or analog).
 */
void ebalPin::read() {

    if (pinType == digital) {
        value = digitalRead(pinNumber);
    }
    else {
        value = analogRead(pinNumber);
    }
}

/**
 * Method that initializes the pin with type, IO and which pin number it is.
 * @param pinT  The pin type the pin should have (digital or analog).
 * @param ioT   The IO type the pin should have (input or output).
 * @param n     The id of the pin on a given Arduino board (e.g. 4 for digital pin 4)
 */

void ebalPin::createPin(PinType pinT, IOType ioT, int n) {
    pinType = pinT;
    ioType = ioT;
    pinNumber = n;

    if (ioType == input) {
        pinMode(pinNumber, INPUT);
    }
    else {
        pinMode(pinNumber, OUTPUT);
    }
}

/**
 * Method that writes a signal to the pin that the ebalPin represents.
 * @param output The value to be written to the pin.
 */
void ebalPin::write(int output) {
    if (pinType == digital) {
        digitalWrite(pinNumber, output);
    }
    else {
        analogWrite(pinNumber, output);
    }
}

/**
 * Getter for the value of the pin.
 * @return Returns the value of the pin.
 */
int ebalPin::getValue() {
    return value;
}

/**
 * Method that filters the noise from a given pin, returning a clean value.
 * @param filter    The filter type that the filternoise method should use (range, debounce or constant).
 * @return          Returns an int that has a filtered value.
 */
int ebalPin::filterNoise(FilterType filter) {
    switch (filter) {
        case debounce:
            return Debounce();

        case range:
            return Range();

        case constant:
            return Constant();
    }
}

/**
 * Used when an analog input needs to be filtered.
 * @return A value between 0 and 255, with an interval of 5.
 * When input is between this interval, returns -1.
 */
int ebalPin::Range() {

    // Maps the pin value to a value between 0 and 255
    int a = map(value, 0, 1023, 0, 255);

    // If the pin value is out of the interval, return the new value
    if (abs(a - previousValue) >= RANGE) {

        // When the pin value is less than the interval,
        // reset the previous value so it is zero based.
        if (a < RANGE) {
            previousValue = 0;
            return a;
        }

        previousValue = a;
        return a;
    }
    // If nothing has changed, return -1
    else {
        return -1;
    }
}

/**
 * Used when a single HIGH signal is needed from an input.
 * @return HIGH once when activated, LOW until activated again.
 */
int ebalPin::Debounce() {
    int returnValue;

    // If the pin value just changed to HIGH,
    // and some time has passed since it did so last,
    // return HIGH
    if (value == HIGH && previousValue == LOW && millis() - lastFilterTime > DEBOUNCE_TIME) {
        lastFilterTime = millis();

        returnValue = HIGH;
    }

    // If it didn't change to HIGH,
    // or not enough time has passed,
    // return LOW
    else {
        returnValue = LOW;
    }

    previousValue = value;
    return returnValue;
}

/**
 * Used when a constant input is needed.
 * @return HIGH once when activated, LOW once when deactivated,
 * and -1 when nothing has changed.
 */
int ebalPin::Constant() {

    // if just changed to HIGH, return HIGH
    if (value == HIGH && previousValue == LOW) {
        previousValue = HIGH;
        return HIGH;
    }

    // if just changed to LOW, return LOW
    else if (value == LOW && previousValue == HIGH) {
        previousValue = LOW;
        return LOW;
    }

    // if constant LOW or HIGH, return -1;
    else {
        return -1;
    }
}
