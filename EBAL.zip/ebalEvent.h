//
// Created by aneso on 29/04/2020.
//

#ifndef EBAL_EBALEVENT_H
#define EBAL_EBALEVENT_H

#include "ebal.h"
#include <Wire.h>
#include <Arduino.h>

#define EVENT_MAX_SLAVES 10

/**
 * Template (generic) class that represents what an event is in EBAL.
 * @tparam T The generic type. Can be either int (int on Arduino is equivalent to a short in cpp, so it has been
 * converted as such here), float or bool.
 */
template<class T>
class ebalEvent {
    int slaves [EVENT_MAX_SLAVES];
    int slaveAmount = -1;

    public:
        T getValue();

        void setID(char id);

        char getID();

        void createEvent(T inputValue);

        void createEvent();

        void addSlave(int address);

        void broadcast();

    protected:
        virtual void convertToSend() = 0;
        virtual T convertToReceive() = 0;

        T value;
        char ID;
};

/**
 * Class that represents an int event in EBAL.
 * The actual type is a short, because an int on Arduino is only 2 bytes.
 * The method convertToSend() converts the short to a byte representation which is then written over wire.
 * The opposite happens with convertToReceive().
 */
class intEvent : public ebalEvent<short> {
    void convertToSend() {

        short toTransfer = value;
        short Shift = toTransfer;
        short mask = 0xFF;
        byte toSend = 0;

        toSend = Shift & mask;
        Shift = Shift >> 8;
        Wire.write(toSend);

        toSend = Shift & mask;
        Wire.write(toSend);
    }

    short convertToReceive() {

        byte received = Wire.read();
        short out = received;

        received = Wire.read();
        out |= (received << 8);

        return out;
    }
};

/**
 * Class that represents a float event in EBAL.
 * The convertToSend() and convertToReceive() methods convert the float to a byte representation for wire communication.
 */
class floatEvent : public ebalEvent<float> {
    void convertToSend() {

        volatile byte* outPtr;
        outPtr = (byte*) &value;

        Wire.write(outPtr[0]);
        Wire.write(outPtr[1]);
        Wire.write(outPtr[2]);
        Wire.write(outPtr[3]);
    }

    float convertToReceive() {

        union ufloat {
            byte b[4];
            float fval;
        } u;

        byte data[4];
        float out;

        for (int i = 0; i < 4; i++) {
            data[i] = Wire.read();
        }

        u.b[0] = data[0];
        u.b[1] = data[1];
        u.b[2] = data[2];
        u.b[3] = data[3];

        out = u.fval;

        return out;
    }
};

/**
 * Class that represents a bool event in EBAL.
 * The convertToSend() and convertToReceive() methods convert the bool to 0 (false) 1 (true) for wire communication.
 */
class boolEvent : public ebalEvent<bool> {
    void convertToSend() {

        if (value) {
            Wire.write('1');
        }
        else {
            Wire.write('0');
        }
    }

    bool convertToReceive() {
        char receive = Wire.read();

        if (receive == '1') {
            return true;
        }

        else if (receive == '0') {
            return false;
        }
        else {
            Serial.println("Bool event error");
            return false;
        }
    }
};

/**
 * Gets the value of an event, e.g. the value from a switch or button.
 * @tparam T The type T, which can be either int, float or bool.
 * @return Returns the value of an event (int, float or bool).
 */
template<class T>
T ebalEvent<T>::getValue() {
    return value;
}

/**
 * Method that initiializes an event to a specific value.
 * @tparam T The type of the value (int, float or bool).
 * @param inputValue The value the event should be initialized with.
 */
template<class T>
void ebalEvent<T>::createEvent(T inputValue) {
    value = inputValue;
}

template<class T>
void ebalEvent<T>::createEvent() {
    value = convertToReceive();
}

/**
 * Method that adds a slave to the
 * @tparam T The type parameter.
 * @param address The address of the slave to be added to list of slaves (addresses).
 */
template<class T>
void ebalEvent<T>::addSlave(int address) {
    slaves[++slaveAmount] = address;
}

/**
 * Method that broadcasts an event to the relevant slaves, as specified in the slaves array which contains addresses
 * of the slaves that handles the event.
 * @tparam T The type parameter.
 */
template<class T>
void ebalEvent<T>::broadcast() {
    for (int i = 0; i <= slaveAmount; i++) {

        Wire.beginTransmission(slaves[i]);

        Wire.write(ID);

        convertToSend();

        Wire.endTransmission();
    }
}

/**
 * Setter for an events ID.
 * @tparam T The type parameter.
 * @param id The new ID for the event.
 */
template<class T>
void ebalEvent<T>::setID(char id) {
    this->ID = id;
}

/**
 * Getter for an events ID.
 * @tparam T The type parameter.
 * @return An events ID.
 */
template<class T>
char ebalEvent<T>::getID() {
    return this->ID;
}

#endif //EBAL_EBALEVENT_H