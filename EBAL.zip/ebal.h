/**
 * This cpp library is intended to be used with the Arduino language EBAL.
 * It contains classes and functions that represent how pins and events should function in EBAL.
 *
 * ~sw417f20
 */

#ifndef _EBAL_H_
#define _EBAL_H_

#include "ebalPin.h"
#include "ebalEvent.h"
#include <Arduino.h>
#include <Wire.h>

#define DEBOUNCE_TIME 300
#define RANGE 5

#endif //_EBAL_H_